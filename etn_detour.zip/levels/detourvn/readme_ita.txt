
(Tradotto in maniera essenziale dal documento originale da FBV-86)

Dati della pista
----------
Nome:              Venice
Length:            617 m
Difficolt�:        Extreme
Autore:            Gabor Varga
E-mail:            bootes@freemail.hu
Altri capolavori:  PetroVolt, Quake!


Descrizione
-----------
Fate un giro nell'incantevole citt� di Venezia (sita in Italia, non in California ;)).
Le vie strette e tortuose della pittoresca cittadina costeggiano gli infiniti canali, nei quali � facilissimo cadere...


Installazione / disinstallazione (Bah...era proprio necessario tradurlo?)
-----------------------------

Cartella :        venice
Installazione:    unzippa Venice.zip nella cartella di Re-volt.
disinstallazione: cancella la cartella <Re-Volt dir>\levels\venice
                  cancella il file <Re-Volt dir>\gfx\venice.bmp
                  cancella il file <Re-Volt dir>\gfx\venice.bmq


Come fare per giocare in modalit� invertit� (Questo � importante!)
----------------

Se ti piace questa pista, allora provala in modalit� inversa.

1-Noterai che nella cartella della pista, c'� un'altra cartella chiamata "reversed"
2-Una volta attivato il file bat. si viene a creare una cartella chiamata "Venice reversed"
3-Dovrai copiare il contenuto della cartella "reversed" (che si trova nella cartella "Venice") nella cartella "Venice revesed"
4-A questo punto puoi giocare sia in senso regolare che invertito.

Buon divertimento,
Gabor
